﻿using System.Collections.ObjectModel;

namespace CardGame.Gui
{
    public class PlayerNumbers : ObservableCollection<int>
    {
        public PlayerNumbers()
          : base()
        {
            Add(2);
            Add(3);
            Add(4);
        }
    }
}
